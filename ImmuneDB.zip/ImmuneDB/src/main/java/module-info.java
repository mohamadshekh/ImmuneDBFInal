 module com.example.immunedb {
    requires javafx.controls;
    requires javafx.fxml;
     requires java.desktop;


     opens com.example.immunedb to javafx.fxml;
    exports com.example.immunedb;
}