package com.example.immunedb;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Button;
import javafx.scene.control.SplitPane;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import javax.swing.*;
import javax.swing.filechooser.FileFilter;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

public class FilePickerController {
private Stage stage;
private String str;
    @FXML
    private TextField txtId;
    @FXML
    private Button Next;
    private static TextArea txtAre;
    @FXML
    private SplitPane split;
    private AnchorPane lowerAnchorPane;

    public void settxt(TextArea txt)
    {
        this.txtAre=txt;
    }
    public void initialize()
    {
        Next.setDisable(false);
    }
    @FXML
    public void start(SplitPane splitpane) throws IOException {
        this.split=splitpane;
        FXMLLoader loader = new FXMLLoader(getClass().getResource("FilePiker.fxml"));
        lowerAnchorPane = loader.load();
        splitpane.getItems().set(0, lowerAnchorPane);
    }
    @FXML
    public void PickFile(ActionEvent actionEvent) throws InterruptedException, IOException {

        File[] selectedFiles=newFIle();
        int result = JOptionPane.showConfirmDialog(null, "Do you want to add another files?", "Confirm", JOptionPane.YES_NO_OPTION);
        while(result == JOptionPane.YES_OPTION)
        {
            File[] tempFIle=newFIle();
            selectedFiles = addArrays(selectedFiles, tempFIle);
            result = JOptionPane.showConfirmDialog(null, "Do you want to add another files?", "Confirm", JOptionPane.YES_NO_OPTION);
        }
        selectedFiles=renameFiles2(selectedFiles);
        MakeDirANdMoveFiles(selectedFiles);
    }

    public File[] newFIle()
    {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setMultiSelectionEnabled(true);

        // Add a file filter to restrict the types of files that can be selected
        FileFilter filter = new FileFilter() {
            public boolean accept(File file) {
                if (file.isDirectory()) {
                    return true;
                }
                String extension = getExtension(file);
                if (extension != null && (extension.equals("fasta") || extension.equals("fastq") || extension.equals("tsv"))) {
                    return true;
                }
                return false;
            }
            public String getDescription() {
                return "Fasta, Fastq, and AIRR TSV Files (*.fasta, *.fastq, *.tsv)";
            }
            private String getExtension(File file) {
                String fileName = file.getName();
                int dotIndex = fileName.lastIndexOf('.');
                if (dotIndex > 0 && dotIndex < fileName.length() - 1) {
                    return fileName.substring(dotIndex + 1).toLowerCase();
                }
                return null;
            }
        };


        fileChooser.setFileFilter(filter);

        int result = fileChooser.showOpenDialog(null);

        if (result == JFileChooser.APPROVE_OPTION) {
            // Get the selected files
            File[] selectedFiles = fileChooser.getSelectedFiles();
            //MakeDirANdMoveFiles(selectedFiles);
            return selectedFiles;

        } else {
            System.out.println("No files selected.");
            return null;
        }
    }

    // add another files
    public static File[] addArrays(File[] originalArray, File[] newArray) {
        int originalLength = originalArray.length;
        int newLength = newArray.length;
        File[] resultArray = Arrays.copyOf(originalArray, originalLength + newLength);
        System.arraycopy(newArray, 0, resultArray, originalLength, newLength);
        return resultArray;
    }

    // in case more than one file have the same name
    public File[] renameFiles2(File[] files)
    {
        Map<String, Integer> fileCountMap = new HashMap<>();
        Random random = new Random();
        for (int i = 0; i < files.length; i++) {
            File file = files[i];
            if (file.isFile()) {
                String fileName = file.getName();
                String fileExtension = "";
                int dotIndex = fileName.lastIndexOf(".");
                if (dotIndex != -1) {
                    fileExtension = fileName.substring(dotIndex);
                    fileName = fileName.substring(0, dotIndex);
                }
                if (fileCountMap.containsKey(fileName)) {
                    int count = fileCountMap.get(fileName);
                    fileCountMap.put(fileName, count + 1);
                    String newFileName = fileName + "_" + random.nextInt(100) + fileExtension; // Appending a random number
                    File renamedFile = new File(file.getParent(), newFileName);
                    file.renameTo(renamedFile);
                    files[i] = renamedFile; // Update the files array with the renamed file
                } else {
                    fileCountMap.put(fileName, 1);
                }
            }
        }

        return files;
    }


    public void MakeDirANdMoveFiles( File[] selectedFiles){

        ExtraData getData = new ExtraData();
        String pathString = getData.getPathTOHome() + "/immunedb_share";

        String directoryName = selectedFiles[0].getName().replaceAll("\\.[^.]*$", "");

        String inputDir = pathString + "/"+directoryName;
        //String inputDir = getData.getPathTOHome() + "/immunedb_share/input";

        // Create a Path object from the path string
        Path path = Paths.get(pathString);

        int i = 1;
        // Use the exists() method to check if the directory exists
        while( Files.exists(path.resolve(directoryName)))
        {
            directoryName = selectedFiles[0].getName().replaceAll("\\.[^.]*$", "") + "_" + i ;
            i++;
        }
        //set the path and the name of the input directory
        getData.setFullpath(inputDir);
        getData.setDirName(directoryName);

        File directory;
        directory = new File(pathString + File.separator + directoryName);
        directory.mkdir();

        // Move the selected files to the new directory
        for (File file : selectedFiles) {
            try {
                Path sourcePath = Paths.get(file.getAbsolutePath());
                Path destinationPath = Paths.get(directory.getAbsolutePath() + File.separator + file.getName());
                Files.move(sourcePath, destinationPath, StandardCopyOption.REPLACE_EXISTING);
            } catch (Exception e) {
                System.out.println("Error moving file: " + e.getMessage());
            }
        }

        System.out.println("Selected files moved to directory: " + directory.getAbsolutePath());
    }




    public void NextFunc(ActionEvent actionEvent) throws Exception {
        ExtraData extra=new ExtraData();
        if(!extra.gettsv())
        {
            int result = JOptionPane.showConfirmDialog(null, "If your data is already in AIRR-compliant IgBLAST format or you are planning on using the built in anchoring method, you can skip this step \n to run IgBLAST press yes", "Confirm", JOptionPane.YES_NO_OPTION);
            if (result == JOptionPane.YES_OPTION) {
                // user pressed the "Yes" button
                IGblastController runIG=new IGblastController();
                runIG.start();
            } else if (result == JOptionPane.NO_OPTION) {
                // user pressed the "No" button
                SettingDataBaseAndMetadataController send=new SettingDataBaseAndMetadataController();
                send.start();
            }
        }
        else
        {
            SettingDataBaseAndMetadataController send=new SettingDataBaseAndMetadataController();
            send.start();
        }
    }
    public void CloseFunc(ActionEvent actionEvent) {
        System.exit(0);
    }




/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //old file picker  add to PickFile function
    //*   File file = getFile();
    //            RunDockerCommandController hi=new RunDockerCommandController();
    //            String id=hi.SetContainerID();
    //            ExtraData extra=new ExtraData();
    //            extra.setConID(id);
    //            if(file!=null) {
    //                makeDir(file);
    //                Next.setDisable(false);
    //            }*//
    //oldd
    public File getFile() {
        File file=null;
        FileChooser fileChooser = new FileChooser();
        file = fileChooser.showOpenDialog(stage);
        if (file != null) {
            File FileType = new File(file.getPath());
            // Get the file name
            String fileName = FileType.getName();
            // Get the file extension
            int index = fileName.lastIndexOf('.');
            String fileExtension = index > 0 ? fileName.substring(index + 1) : "";
            //if (!(fileExtension.equals("fasta") && !(fileExtension.equals("fastq")) && !(fileExtension.equals("tsv"))))
            if(!(fileExtension.equals("fasta") || fileExtension.equals("fastq") || fileExtension.equals("tsv"))){
                String message = "The input file Extension must be FASTA/FASTQ or airr tsv ";
                String title = "Error";
                JOptionPane.showMessageDialog(null, message, title, JOptionPane.ERROR_MESSAGE);
                file=null;
            }
            else
            {
                txtId.setText(file.getPath());
                if(fileExtension.equals("tsv"))
                {
                    ExtraData extr=new ExtraData();
                    extr.settsv(true);
                }
            }

        }
      return file;
    }
    //oldd
    public void moveFiles(String src,String des,String ext)
    {
        //File sourceDir = new File(src);
        File destDir = new File(des);
        String[] extensions = {".fasta", ".fastq"};
        // Create the destination directory if it doesn't exist
        if (!destDir.exists()) {
            destDir.mkdir();
        }
        // Get all the files in the source directory

        File[] files = new File(src).listFiles();
        if(ext.equals("*"))//moving all the files to another directory
        {
            for (File file : files) {
                try {
                    Path sourcePath = Paths.get(file.getAbsolutePath());
                    Path targetPath = Paths.get(destDir + "/" + file.getName());
                    Files.move(sourcePath, targetPath);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        else { // Move all files with the specified extension to the destination directory
            for (File file : files) {
                for (String exts : extensions) {
                    if (file.getName().endsWith(exts)) {
                        try {
                            Path sourcePath = Paths.get(file.getAbsolutePath());
                            Path targetPath = Paths.get(destDir + "/" + file.getName());
                            Files.move(sourcePath, targetPath);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }
            }
        }



    }
    //oldd
    public void makeDir(File file) {
        ExtraData getData = new ExtraData();
        String inputDir = getData.getPathTOHome() + "/immunedb_share/input";
        String directoryName = "input";
        String pathString = getData.getPathTOHome() + "/immunedb_share";

        // Create a Path object from the path string
        Path path = Paths.get(pathString);

        getData.setFullpath(pathString);
        // Use the exists() method to check if the directory exists
        boolean directoryExists = Files.exists(path.resolve(directoryName));
        if (!directoryExists) {
            new File(inputDir).mkdir();
        }

        System.out.println("source path" + file.getPath());
        System.out.println("dest path" + inputDir);
        Path source = Paths.get(file.getPath());
        Path destination = Paths.get(inputDir);
        // Move the file
        Path destinationPath = Paths.get(destination + "/" + file.getName());
            try {
                Files.move(source, destination.resolve(source.getFileName()));
            } catch (IOException e) {
                e.printStackTrace();
            }
    }
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
}

