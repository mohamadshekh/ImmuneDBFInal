package com.example.immunedb;

import javafx.collections.FXCollections;
import javafx.concurrent.Task;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.*;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import javax.swing.*;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class ExportingData {

    public Label label;
    static String path;
    @FXML
    private static SplitPane split;
    public Button exportSA;
    public Button ExportCl;
    public Button ExportSeq;
    public CheckBox airr;
    public CheckBox filter;
    public CheckBox filtersampleSelection;
    public Button SelectionButton;
    private AnchorPane lowerAnchorPane;
    private RunDockerCommandController runCommand;
    public ComboBox field;
    private  String message;

    private static TextArea txtAre;

    public void settxt(TextArea txt)
    {
        this.txtAre=txt;
    }
    public void setSplit(SplitPane ss)
    {
        split=ss;
    }
    @FXML
    public void initialize() {
        ExtraData extra=new ExtraData();
        path="/share/configs/"+extra.getDBname()+".json";
        runCommand=new RunDockerCommandController();

        String filePath =   extra.getPathTOHome() + "/immunedb_share/"+extra.getDirName();
        try {
            BufferedReader reader = new BufferedReader(new FileReader(filePath));
            String headerLine = reader.readLine();
            String[] headers = headerLine.split("\t");
            field.setItems(FXCollections.observableArrayList(headers));
            System.out.println("Headers:");
            for (String header : headers) {
                System.out.println(header);
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }



    }
    public void start() throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("ExportingData.fxml"));
        lowerAnchorPane = loader.load();
        split.getItems().set(0, lowerAnchorPane);
    }

    public void exitbtn(ActionEvent actionEvent) {
        runCommand();

        System.exit(0);
    }
    private void runCommand()
    {
        LoadingDialog dialog = new LoadingDialog();
        Task<Void> task = new Task<Void>() {
            @Override
            protected Void call() throws Exception {
                split.setDisable(true);
                // Perform long-running operation here
                Thread.sleep(1000);
                ExtraData data=new ExtraData();
                RunDockerCommandController run=new RunDockerCommandController();
                run.DeleteExistingContainer(data.getConID());
                split.setDisable(false);
                return null;
            }
        };

        Stage s=new Stage();
        try {
            dialog.start(s);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        dialog.show("Performing Step... ", task);
    }

    public void ExportingSAmple(ActionEvent actionEvent) {
        String command=" immunedb_export "+path;
        command+=" samples";
        runCommand2(command,exportSA);

    }
    public void ExportSelectionPressure(ActionEvent actionEvent) {
        String command=" immunedb_export "+path;
        command+=" selection";
        runCommand2(command,SelectionButton);

    }
    public void ExportingClones(ActionEvent actionEvent) {
        String command=" immunedb_export "+path;
        command+=" clones";
        runCommand2(command,ExportCl);
    }
    public void ExportingSequences(ActionEvent actionEvent) {
        String command=" immunedb_export "+path;
        if(airr.isSelected())
            command+=" sequences --format airr";
        if(filter.isSelected())
            command+=" --clones-only";
        runCommand2(command,ExportSeq);
    }
    private void runCommand2(String command,Button btn)
    {
        LoadingDialog dialog = new LoadingDialog();
        Task<Void> task = new Task<Void>() {
            @Override
            protected Void call() throws Exception {
                split.setDisable(true);
                btn.setDisable(true);
                runCommand.RunDockerCommand(command);
                split.setDisable(false);
                return null;
            }
        };
        Stage s=new Stage();
        try {
            dialog.start(s);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        dialog.show("Performing Step... ", task);
    }

    public void info(ActionEvent actionEvent) {
         message="By default, the data is aggregated by the value of the sample, if you want to choose different value (from the header of the metadata file) \n you can choos from the choice box  default is sample";
        JOptionPane.showMessageDialog(null, message, "information", JOptionPane.INFORMATION_MESSAGE);
    }

    public void info1(ActionEvent actionEvent) {
         message="in default the sequence export will generate one file per sample in CHange-O formate, to change the formate to AIRR format sign the check box";
        JOptionPane.showMessageDialog(null, message, "information", JOptionPane.INFORMATION_MESSAGE);
    }

    public void info2(ActionEvent actionEvent) {
     message="You can filter out sequences that were not assigned to a clone by sign the check box  ";
    JOptionPane.showMessageDialog(null, message, "information", JOptionPane.INFORMATION_MESSAGE);
    }

    public void info3(ActionEvent actionEvent) {
        message="By checking the checkbox, there will be one additional row per clone with a All Samples value for the sample which indicates the overall selection pressure on the clone.";
        JOptionPane.showMessageDialog(null, message, "information", JOptionPane.INFORMATION_MESSAGE);
    }


}
