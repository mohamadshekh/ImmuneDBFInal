package com.example.immunedb;

import javafx.collections.FXCollections;
import javafx.concurrent.Task;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.text.Text;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

import javax.swing.*;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
public class HelloController {
    public TextArea input;
    public Button Run;
    public Button next;

    @FXML
    private SplitPane splitpane;

    public void initialize() {
      Run.setDisable(true);
      next.setDisable(true);
    }
    public void start(Stage stage) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("HomePage.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        URL url = getClass().getResource("test2.css");
        String css = url.toExternalForm();
        scene.getStylesheets().add(css);
        stage.setScene(scene);
        stage.setResizable(false);
        stage.show();
    }

    @FXML//run docker container
    protected void onHelloButtonClick() throws Exception {

        //run.DokerRun();

        LoadingDialog dialog = new LoadingDialog();
        Task<Void> task = new Task<Void>() {
            @Override
            protected Void call() throws Exception {

                String imageId="";

                //check of existing running container
                RunDockerCommandController run=new RunDockerCommandController();
                imageId=run.SetContainerID();

                if(!imageId.equals(""))//in case of existing container with the immunedb image, delete that container
                    run.DeleteExistingContainer(imageId);

                String containerID="";
                splitpane.setDisable(true);

                // Perform long-running operation here
                Thread.sleep(2000);
                run.DokerRunContainerNew();
                Thread.sleep(2000);

                containerID=run.SetContainerID();
                ExtraData extra=new ExtraData();
                extra.setConID(containerID);

                splitpane.setDisable(false);
                next.setDisable(false);

                // test t=new test();
                //t.RunDockerCommand2();
                return null;
            }
        };

        Stage s=new Stage();
        try {
            dialog.start(s);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        dialog.show("Performing Step... ", task);
        next.setDisable(false);

    }

    private void SettxtandSplit() {
        ClonalAssignment CLA=new ClonalAssignment();
        CloneTree CLT =new CloneTree();
        FilePickerController FIP=new FilePickerController();
        IGblastController IG=new IGblastController();
        ImportingOutput IMP=new ImportingOutput();
        OptionalSteps OPS=new OptionalSteps();
        RunDockerCommandController Run=new RunDockerCommandController();
        SettingDataBaseAndMetadataController DB= new SettingDataBaseAndMetadataController();
        StatisticsGeneration sta=new StatisticsGeneration();
        LastScreen ls=new LastScreen();
        ExportingData expor=new ExportingData();
        expor.setSplit(splitpane);
        expor.settxt(input);
        ls.setSplit(splitpane);
        ls.settxt(input);
        CLA.settxt(input);
        CLA.setSplit(splitpane);
        CLT.setTxtAre(input);
        CLT.setSplit(splitpane);
        FIP.settxt(input);
        IG.settxt(input);
        IG.setSplit(splitpane);
        IMP.setSplit(splitpane);
        IMP.settxt(input);
        OPS.setSplit(splitpane);
        OPS.settxt(input);
        Run.settxt(input);
        DB.settxt(input);
        DB.setSplit(splitpane);
        sta.setSplit(splitpane);
        sta.settxt(input);
    }
    //get the container ID


    public void PullCommand(ActionEvent actionEvent) {
        ExtraData extra =new ExtraData();
        SettxtandSplit();
        String homeDir = System.getProperty("user.home");
        extra.setPathTOHome(homeDir);//path to home dir
        extra.setFullpath(homeDir+"/immunedb_share");//path to the input dir
        input.appendText("full path "+extra.getFullpath());
        input.appendText("\n path to home "+extra.getPathTOHome());
        RunDockerCommandController run=new RunDockerCommandController();

        LoadingDialog dialog = new LoadingDialog();
        Task<Void> task = new Task<Void>() {
            @Override
            protected Void call() throws Exception {
                splitpane.setDisable(true);

                // Perform long-running operation here
                Thread.sleep(1500);
                run.DockerPull2();
                Run.setDisable(false);
                splitpane.setDisable(false);


                return null;
            }
        };

        Stage s=new Stage();
        try {
            dialog.start(s);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        dialog.show("Performing Step... ", task);

        //run.DockerPull(Run);

    }

    public void RunCommand(){

        LoadingDialog dialog = new LoadingDialog();
        Task<Void> task = new Task<Void>() {
            @Override
            protected Void call() throws Exception {
                splitpane.setDisable(true);

                // Perform long-running operation here
                Thread.sleep(10000);

                splitpane.setDisable(false);


                return null;
            }
        };

        Stage s=new Stage();
        try {
            dialog.start(s);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        dialog.show("Performing Step... ", task);

    }

    public void NextStep(ActionEvent actionEvent) throws IOException {
       // FilePickerController file2 = new FilePickerController();
       // file2.start(splitpane);
        SettingDataBaseAndMetadataController set=new SettingDataBaseAndMetadataController();
        set.start();
    }
}




