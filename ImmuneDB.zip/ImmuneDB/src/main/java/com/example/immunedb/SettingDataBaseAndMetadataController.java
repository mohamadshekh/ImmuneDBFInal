package com.example.immunedb;

import javafx.beans.value.ChangeListener;
import javafx.concurrent.Task;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Button;
import javafx.scene.control.SplitPane;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import javax.swing.*;
import javax.swing.filechooser.FileFilter;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

public class SettingDataBaseAndMetadataController {
    public TextField dataBaseName;
    public Button CreatDAta;
    public Button next;
    public Button metaButtn;
    public Button ChooseButt;
    private ExtraData Data;
    @FXML
    private static SplitPane split;
    private static TextArea txtAre;
    private AnchorPane lowerAnchorPane;
    private String dataName;

    public void settxt(TextArea txt)
    {
        this.txtAre=txt;
    }
    public void setSplit(SplitPane ss)
    {
        split=ss;
    }

    @FXML
    public void initialize() {
        dataBaseName.setText(dataName);
        next.setDisable(true);
        dataBaseName.setDisable(true);
        CreatDAta.setDisable(true);
        Data=new ExtraData();
        metaButtn.setDisable(true);
        ChooseButt.setDisable(true);
        dataBaseName.textProperty().addListener(textListener);

    }

    public void start() throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("DataBaseName.fxml"));
        lowerAnchorPane = loader.load();
        split.getItems().set(0, lowerAnchorPane);
    }

    public void Metadata()
    {
        RunDockerCommandController run = new RunDockerCommandController();
        if (run.metadata2(Data.getDirName())) {
            String path = Data.getFullpath();
            String message = "The metadata sheet has benn created \n on " + path + " open the metadata file in Excel or your favorite spreadsheet editor \n he headers included in the file are required ";
            String title = "notification";
            JOptionPane.showMessageDialog(null, message, title, JOptionPane.INFORMATION_MESSAGE);
            message = "you must edit the metadata file else other steps of the immuneDB will no work";
            title = "notification";
            JOptionPane.showMessageDialog(null, message, title, JOptionPane.INFORMATION_MESSAGE);
            dataBaseName.setDisable(false);
            CreatDAta.setDisable(false);
            ChooseButt.setDisable(false);
        }
    }

    public void GetDatabaseName() {
        boolean hasDigit=false;
        if(!dataBaseName.getText().equals(""))
        {
            dataName=dataBaseName.getText();
            for (int i = 0; i < dataName.length(); ++i) {
                if (Character.isDigit(dataName.charAt(i))) {
                    hasDigit = true;
                }
            }
            if(hasDigit)
            {
                String message = "The DataBase name must not contain digits, try entring another name ";
                String title = "Error";
                JOptionPane.showMessageDialog(null, message, title, JOptionPane.ERROR_MESSAGE);
            }
            else
                CreatDAta.setDisable(false);
        }
        else
            CreatDAta.setDisable(true);
    }
    public void RunDataBase(ActionEvent actionEvent) throws IOException {
            Path path = Paths.get(Data.getFullpath()+"/mysql_data");//path.resolve(dataName)
            boolean directoryExists = Files.exists(Path.of(path + "/" + dataName));
            if (directoryExists) {
                String message = "The DataBase name already exists, please insert another name ";
                String title = "Error";
                JOptionPane.showMessageDialog(null, message, title, JOptionPane.ERROR_MESSAGE);
            }
            else
                SetDataBase(dataName);
    }

    public void SetDataBase(String dataname)//immunedb_admin create my_db /share/configs
    {
        LoadingDialog dialog = new LoadingDialog();
        Task<Void> task = new Task<Void>() {
            @Override
            protected Void call() throws Exception {
                split.setDisable(true);
                ChooseButt.setDisable(true);
                RunDockerCommandController run=new RunDockerCommandController();
                String command =" immunedb_admin create ";
                command+=dataName;
                command+=" /share/configs";
                txtAre.appendText("\n database  "+command);

                run.RunDockerCommand(command);

                split.setDisable(false);
                next.setDisable(false);
                return null;
            }
        };

        Stage s=new Stage();
        try {
            dialog.start(s);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        dialog.show("Performing Step... ", task);
        //return run.RunDockerCommand2(command,next);
    }
    public void NextBtn(ActionEvent actionEvent) throws IOException {
        ImportingOutput imprt=new ImportingOutput();
        imprt.start();
    }

    ChangeListener<String> textListener = (observable, oldValue, newValue) -> {
        GetDatabaseName();
    };


    public void ChooseExistingDAtabase(ActionEvent actionEvent) {
        ExtraData getData=new ExtraData();
        String pathString = getData.getPathTOHome() + "/immunedb_share/configs";

        JFileChooser fileChooser = new JFileChooser(pathString);
        fileChooser.setFileFilter(new FileNameExtensionFilter("JSON files", "json"));
        int result = fileChooser.showOpenDialog(null);
        if (result == JFileChooser.APPROVE_OPTION) {
            File selectedFile = fileChooser.getSelectedFile();
            String fileName = selectedFile.getName().replace(".json", "");
            System.out.println("Selected file name without extension: " + fileName);
            //SetDataBase(fileName);
            getData.setDBname(fileName);
            next.setDisable(false);

        }
    }

    public void FIlePicker(ActionEvent actionEvent) {

        File[] selectedFiles=newFIle();
        int result = JOptionPane.showConfirmDialog(null, "Do you want to add another files?", "Confirm", JOptionPane.YES_NO_OPTION);
        while(result == JOptionPane.YES_OPTION)
        {
            File[] tempFIle=newFIle();
            selectedFiles = addArrays(selectedFiles, tempFIle);
            result = JOptionPane.showConfirmDialog(null, "Do you want to add another files?", "Confirm", JOptionPane.YES_NO_OPTION);
        }
        selectedFiles=renameFiles2(selectedFiles);
        MakeDirANdMoveFiles(selectedFiles);
        metaButtn.setDisable(false);
    }
    public File[] newFIle()
    {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setMultiSelectionEnabled(true);

        // Add a file filter to restrict the types of files that can be selected
        FileFilter filter = new FileFilter() {
            public boolean accept(File file) {
                if (file.isDirectory()) {
                    return true;
                }
                String extension = getExtension(file);
                if (extension != null && (extension.equals("fasta") || extension.equals("fastq") || extension.equals("tsv"))) {
                    return true;
                }
                return false;
            }
            public String getDescription() {
                return "Fasta, Fastq, and AIRR TSV Files (*.fasta, *.fastq, *.tsv)";
            }
            private String getExtension(File file) {
                String fileName = file.getName();
                int dotIndex = fileName.lastIndexOf('.');
                if (dotIndex > 0 && dotIndex < fileName.length() - 1) {
                    return fileName.substring(dotIndex + 1).toLowerCase();
                }
                return null;
            }
        };


        fileChooser.setFileFilter(filter);

        int result = fileChooser.showOpenDialog(null);

        if (result == JFileChooser.APPROVE_OPTION) {
            // Get the selected files
            File[] selectedFiles = fileChooser.getSelectedFiles();
            //MakeDirANdMoveFiles(selectedFiles);
            return selectedFiles;

        } else {
            System.out.println("No files selected.");
            return null;
        }
    }

    // add another files
    public static File[] addArrays(File[] originalArray, File[] newArray) {
        int originalLength = originalArray.length;
        int newLength = newArray.length;
        File[] resultArray = Arrays.copyOf(originalArray, originalLength + newLength);
        System.arraycopy(newArray, 0, resultArray, originalLength, newLength);
        return resultArray;
    }

    // in case more than one file have the same name
    public File[] renameFiles2(File[] files)
    {
        Map<String, Integer> fileCountMap = new HashMap<>();
        Random random = new Random();
        for (int i = 0; i < files.length; i++) {
            File file = files[i];
            if (file.isFile()) {
                String fileName = file.getName();
                String fileExtension = "";
                int dotIndex = fileName.lastIndexOf(".");
                if (dotIndex != -1) {
                    fileExtension = fileName.substring(dotIndex);
                    fileName = fileName.substring(0, dotIndex);
                }
                if (fileCountMap.containsKey(fileName)) {
                    int count = fileCountMap.get(fileName);
                    fileCountMap.put(fileName, count + 1);
                    String newFileName = fileName + "_" + random.nextInt(100) + fileExtension; // Appending a random number
                    File renamedFile = new File(file.getParent(), newFileName);
                    file.renameTo(renamedFile);
                    files[i] = renamedFile; // Update the files array with the renamed file
                } else {
                    fileCountMap.put(fileName, 1);
                }
            }
        }

        return files;
    }

    public void MakeDirANdMoveFiles( File[] selectedFiles){

        ExtraData getData = new ExtraData();
        String pathString = getData.getPathTOHome() + "/immunedb_share";

        String directoryName = selectedFiles[0].getName().replaceAll("\\.[^.]*$", "");

        String inputDir = pathString + "/"+directoryName;
        //String inputDir = getData.getPathTOHome() + "/immunedb_share/input";

        // Create a Path object from the path string
        Path path = Paths.get(pathString);

        int i = 1;
        // Use the exists() method to check if the directory exists
        while( Files.exists(path.resolve(directoryName)))
        {
            directoryName = selectedFiles[0].getName().replaceAll("\\.[^.]*$", "") + "_" + i ;
            i++;
        }
        //set the path and the name of the input directory
        getData.setFullpath(inputDir);
        getData.setDirName(directoryName);

        File directory;
        directory = new File(pathString + File.separator + directoryName);
        directory.mkdir();

        // Move the selected files to the new directory
        for (File file : selectedFiles) {
            try {
                Path sourcePath = Paths.get(file.getAbsolutePath());
                Path destinationPath = Paths.get(directory.getAbsolutePath() + File.separator + file.getName());
                Files.move(sourcePath, destinationPath, StandardCopyOption.REPLACE_EXISTING);
            } catch (Exception e) {
                System.out.println("Error moving file: " + e.getMessage());
            }
        }

        System.out.println("Selected files moved to directory: " + directory.getAbsolutePath());
    }


}
