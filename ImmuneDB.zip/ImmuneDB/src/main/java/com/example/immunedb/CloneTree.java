package com.example.immunedb;

import javafx.beans.value.ChangeListener;
import javafx.collections.FXCollections;
import javafx.concurrent.Task;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.*;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import javax.swing.*;
import java.io.IOException;

public class CloneTree {
    @FXML
    private static SplitPane split;
    public ComboBox Exclude;
    public ComboBox include;
    public TextField seqSample;
    public TextField MutationSam;
    public TextField MutationCop;
    public TextField seqCopies;
    public Button skip;
    public Button run;
    public Button RunRecommended;
    public Button next;
    private RunDockerCommandController runCommand;
    private ExtraData extra;
    private AnchorPane lowerAnchorPane;
    private static TextArea txtAre;
    private String message="";
    private String AddCommand="";

    public void setTxtAre(TextArea txtAre) {
        this.txtAre = txtAre;
    }

    public void setSplit(SplitPane split) {
        this.split = split;
    }
    @FXML
    public void initialize() {
        next.setDisable(true);
        runCommand=new RunDockerCommandController();
        extra=new ExtraData();
        Exclude.setItems(FXCollections.observableArrayList("false","true"));
        include.setItems(FXCollections.observableArrayList("false","true"));
        seqSample.textProperty().addListener(textListener);
        MutationSam.textProperty().addListener(textListener);
        MutationCop.textProperty().addListener(textListener);
        seqCopies.textProperty().addListener(textListener);

    }
    public void start() throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("CloneTree.fxml"));
        lowerAnchorPane = loader.load();
        split.getItems().set(0, lowerAnchorPane);
    }

    public void RunByDefault(ActionEvent actionEvent) {

        run.setDisable(true);
        DIsableINput();

        // run this command immunedb_clone_trees /share/configs/example_db.json --min-seq-copies 2
        extra=new ExtraData();
        String command=" immunedb_clone_trees /share/configs/";
        command+= extra.getDBname();
        command+=".json --min-seq-copies 2";
        txtAre.appendText("\n clonal tree recomended "+command);

        runCommand2(command,next);

        //RunDockerCommandController run =new RunDockerCommandController();
        //run.RunDockerCommand(command);


    }
    private void runCommand2(String command,Button btn)
    {
        LoadingDialog dialog = new LoadingDialog();
        Task<Void> task = new Task<Void>() {
            @Override
            protected Void call() throws Exception {
                split.setDisable(true);
                runCommand.RunDockerCommand(command);
                split.setDisable(false);
                btn.setDisable(false);
                return null;
            }
        };

        Stage s=new Stage();
        try {
            dialog.start(s);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        dialog.show("Performing Step... ", task);

    }

    public void SkipBT(ActionEvent actionEvent) throws IOException {
        //make the last screen to show the web
        LastScreen last=new LastScreen();
        last.start();
    }

    public void DIsableINput()
    {
        skip.setDisable(true);

        MutationCop.setDisable(true);
        MutationSam.setDisable(true);
        seqSample.setDisable(true);
        seqCopies.setDisable(true);
        Exclude.setDisable(true);
        include.setDisable(true);
    }

    public void RunBt(ActionEvent actionEvent) {
        //run with the AddCommand   immunedb_clone_trees /share/configs/example_db.json
        RunRecommended.setDisable(true);
        DIsableINput();

         extra=new ExtraData();
        String command=" immunedb_clone_trees /share/configs/";
        command+= extra.getDBname();
        command+=".json";
        command+=getInput();
        //command+=AddCommand;
        txtAre.appendText("\n clonal tree "+command);
        runCommand2(command,next);
        //RunDockerCommandController run =new RunDockerCommandController();
        //run.RunDockerCommand(command);
    }

    private String getInput()
    {
        String InputCommand="";
       if(!(seqCopies.equals(""))||!(castToInteger(seqCopies)==0))
       {
           InputCommand+=" --min-seq-copies ";
           InputCommand+=seqCopies.getText();
       }
        if(!(seqSample.equals(""))||!(castToInteger(seqSample)==0))
        {
            InputCommand+= " --min-seq-samples ";
            InputCommand+=seqSample.getText();
        }
        if(!(MutationCop.equals(""))||!(castToInteger(MutationCop)==0))
        {
            InputCommand+=" --min-mut-copies ";
            InputCommand+=MutationCop.getText();
        }
        if(!(MutationSam.equals(""))||!(castToInteger(MutationSam)==0))
        {
            InputCommand+=" --min-mut-samples ";
            InputCommand+=MutationSam.getText();
        }
        if(!Exclude.getValue().equals("false"))
        {
            InputCommand+=" --exclude-stops "+Exclude.getValue();
        }
        if(!include.getValue().equals("true"))
        {
            InputCommand+=" --full-seq "+include.getValue();
        }
        return InputCommand;
    }

    private int castToInteger(TextField text)
    {
        int value = 0;
        try {
             value = Integer.parseInt(text.getText());
        } catch (NumberFormatException e) {
            showInfo("Wrong input, must be greater or equal to zero");
        }
        return value;
    }


    public void showInfo(String tit) {
        JOptionPane.showMessageDialog(null, message, tit, JOptionPane.INFORMATION_MESSAGE);
    }

    ChangeListener<String> textListener = (observable, oldValue, newValue) -> {
        try {
            if (!newValue.equals("")) {
                int input = Integer.parseInt(newValue);
            }
        } catch (NumberFormatException e) {
            showInfo("Wrong input, must be greater or equal to zero");
        }
    };



    public void info1(ActionEvent actionEvent) {
        this.message="The minimum number samples in which a sequence must appear for it to be included in the tree.. default 0";
        showInfo("Information");
    }

    public void info2(ActionEvent actionEvent) {
        this.message="The minimum number copy number required for a sequence to be included in the tree. default 0";
        showInfo("Information");
    }

    public void info3(ActionEvent actionEvent) {
        this.message="The minimum number of copies in which a mutation must occur to be included in the tree. default 0";
        showInfo("Information");
    }

    public void info4(ActionEvent actionEvent) {
        this.message="The minimum number of samples in which a mutation must occur to be included in the tree. default 0";
        showInfo("Information");
    }

    public void info5(ActionEvent actionEvent) {
        this.message="Exclude sequences with a stop codon. default false ";
        showInfo("Information");
    }
    public void info6(ActionEvent actionEvent) {
        this.message="By default only the V-region of each sequence (the portion 5’ of the CDR3) is included in the tree construction. Setting this flag will use the entire sequence. default false";
        showInfo("Information");
    }

    ////////////////////////old///////////////////////////////////////
    public void GetSequSample(ActionEvent actionEvent) {
        try {
            int input = Integer.parseInt(seqSample.getText());
            AddCommand+=" --min-seq-samples ";
            AddCommand+=seqSample.getText();
            // Input is a valid integer, do something with it
        } catch (NumberFormatException e) {
            this.message="Please enter a valid integer";
            showInfo("Error");
        }

    }


    public void getSequCop(ActionEvent actionEvent) {

        try {
            int input = Integer.parseInt(seqCopies.getText());
            AddCommand+=" --min-seq-copies ";
            AddCommand+=seqCopies.getText();
            // Input is a valid integer, do something with it
        } catch (NumberFormatException e) {
            this.message="Please enter a valid integer";
            showInfo("Error");
        }
    }

    public void GetMutationCop(ActionEvent actionEvent) {
        try {
            int input = Integer.parseInt(MutationCop.getText());
            AddCommand+=" --min-mut-copies ";
            AddCommand+=MutationCop.getText();
            // Input is a valid integer, do something with it
        } catch (NumberFormatException e) {
            this.message="Please enter a valid integer";
            showInfo("Error");
        }
    }

    public void GetMutationSam(ActionEvent actionEvent) {
        try {
            int input = Integer.parseInt(MutationSam.getText());
            AddCommand+=" --min-mut-samples ";
            AddCommand+=MutationSam.getText();
            // Input is a valid integer, do something with it
        } catch (NumberFormatException e) {
            this.message="Please enter a valid integer";
            showInfo("Error");
        }
    }

    public void getExclude(ActionEvent actionEvent) {
        AddCommand+=" --exclude-stops "+Exclude.getValue();
    }

    public void getInclude(ActionEvent actionEvent) {
        AddCommand+=" --full-seq "+include.getValue();
    }

    //////////////////////////////////////////////////////////////////


}
