package com.example.immunedb;

public class ExtraData {
    static private String ConID;//container id

    static private String DirName;// input directory name

    static private String PathTOHome;//path to the home directory
    static private String PathToInputFile;//path to the input directory
    static boolean Igblast=false;
    static private String DBname;

    static boolean istsv=false;

    public static boolean isSelection() {
        return selection;
    }

    public static void setSelection(boolean selection) {
        ExtraData.selection = selection;
    }

    static boolean selection=false;

    public  String getDBname() {
        return DBname;
    }

    public  void setDBname(String DBname) {
        ExtraData.DBname = DBname;
    }

    public void setFullpath(String fullpath) {
        ExtraData.PathToInputFile = fullpath;
    }
    public String getFullpath() {
        return PathToInputFile;
    }

    public void setConID(String conName) {
        ConID = conName;
    }
    public String getConID()
    {
        return ConID;
    }
    public void setPathTOHome(String pathfor) {
        PathTOHome = pathfor;
    }
    public String getPathTOHome()
    {
        return PathTOHome;
    }

    public  void setIgblast(boolean igblast) {
        Igblast = igblast;
    }
    public boolean getIgblast()
    {
        return Igblast;
    }
    public  void settsv(boolean flag) {
        istsv = flag;
    }
    public boolean gettsv()
    {
        return istsv;
    }

    public  String getDirName() {
        return DirName;
    }

    public  void setDirName(String dirName) {
        DirName = dirName;
    }


}
