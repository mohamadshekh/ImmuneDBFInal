package com.example.immunedb;

import javafx.collections.FXCollections;
import javafx.concurrent.Task;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.SplitPane;
import javafx.scene.control.TextArea;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import javax.swing.*;
import java.io.IOException;

public class IGblastController {
    public Button next;
    @FXML
    private Button Skip;
    @FXML
    private Button Run;
    @FXML
    private ComboBox<String> Specis;
    @FXML
    private ComboBox<String> locus;
    private String Sp="";
    private String lc="";

    @FXML
    private static SplitPane split;
    private AnchorPane lowerAnchorPane;
    private static TextArea txtAre;
    private static boolean flag=false;

    public  void setFlag(boolean flag) {
        this.flag = flag;
    }
    public void settxt(TextArea txt)
    {
        this.txtAre=txt;
    }
    public void setSplit(SplitPane ss)
    {
        split=ss;
    }
    @FXML
    public void initialize() {
        if(flag)
            Skip.setDisable(true);
        next.setDisable(true);
        Run.setDisable(true);
        Specis.setItems(FXCollections.observableArrayList("human","mouse"));
        locus.setItems(FXCollections.observableArrayList("IGH","IGL","IGK","TRA","TRB"));
    }
    public void start() throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("IGblast.fxml"));
        lowerAnchorPane = loader.load();
        split.getItems().set(0, lowerAnchorPane);
    }
    public void GetSp(ActionEvent actionEvent) {
        Sp=Specis.getValue();
        checkRNbtn();
    }

    public void GetLoc(ActionEvent actionEvent) {
        lc=locus.getValue();
        checkRNbtn();
    }
    public void checkRNbtn()
    {
        if(!Sp.equals("")&&!lc.equals(""))
            Run.setDisable(false);
    }
    public void RunButt(ActionEvent actionEvent) throws IOException {
        LoadingDialog dialog = new LoadingDialog();
        Task<Void> task = new Task<Void>() {
            @Override
            protected Void call() throws Exception {
                split.setDisable(true);
                RunDockerCommandController run=new RunDockerCommandController();
                ExtraData extra=new ExtraData();
                extra.setIgblast(true);
                String command =" run_igblast.sh ";
                command+=Sp;
                command +=" ";
                command+=lc;
                command+=" /share/"+extra.getDirName()+" /share/"+extra.getDirName();
                // command+=" /share/input /share/input";
                txtAre.appendText("\n igblast  "+command);
                run.RunDockerCommand(command);
                //run.RunDockerCommand2(command,next);
                next.setDisable(false);
                split.setDisable(false);

                return null;
            }
        };

        Stage s=new Stage();
        try {
            dialog.start(s);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        dialog.show("Performing Step... ", task);
    }
    public void SkipButton(ActionEvent actionEvent) throws IOException {
        if(flag)
        {
            ImportingOutput im=new ImportingOutput();
            im.start();
        }
        else {
            SettingDataBaseAndMetadataController send=new SettingDataBaseAndMetadataController();
            send.start();
        }
    }
}
