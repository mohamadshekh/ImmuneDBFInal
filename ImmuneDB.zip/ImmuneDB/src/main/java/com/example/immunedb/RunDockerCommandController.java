package com.example.immunedb;

import javafx.application.Platform;
import javafx.concurrent.Service;
import javafx.concurrent.Task;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;

import javax.print.Doc;
import javax.swing.*;
import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CountDownLatch;

public class RunDockerCommandController {

    private String contID;
    private static TextArea txtAre;
    public void settxt(TextArea txt)
    {
        this.txtAre=txt;
    }



    ////////////////////////////////////NEW COMMANDS///////////////////////////////////////////////////


    //change the function calls from the classes to the new functions and add the loading dialog code



    public void DokerRunContainerNew()
    {
        Process runProcess ;
        String command;
        try{
            ExtraData extra=new ExtraData();
            command="docker run -v ";
            command +=extra.getFullpath();
            command+=":/share -p 8080:8080 -it -d arosenfeld/immunedb";
            runProcess = Runtime.getRuntime().exec(command);
            int exitStatus = runProcess.waitFor();
        } catch (IOException e) {
            throw new RuntimeException(e);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        BufferedReader stderr = new BufferedReader(new InputStreamReader(runProcess.getErrorStream()));
        String line;
        BufferedReader stdout = new BufferedReader(new InputStreamReader(runProcess.getInputStream()));
        try{

            while ((line = stdout.readLine()) != null) {
                txtAre.appendText(line);
                txtAre.appendText("\n");
            }
            while ((line = stderr.readLine()) != null) {
                txtAre.appendText(line);
                txtAre.appendText("\n");
            }

        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }


    public void DeleteExistingContainer(String id)
    {
        try {
            ProcessBuilder builder = new ProcessBuilder("docker", "stop",id);
            Process process = builder.start();
            process.waitFor();

        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }

        try {
            ProcessBuilder builder = new ProcessBuilder("docker", "rm",id,id);
            Process process = builder.start();
            process.waitFor();
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
    }
    public String SetContainerID() throws IOException {

        String containerId = "";
        try {
            ProcessBuilder builder = new ProcessBuilder(//image id
                    "docker", "ps","-a", "-aqf", String.format("ancestor=%s", "arosenfeld/immunedb"));
            Process process = builder.start();
            BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
            containerId = reader.readLine();
            process.waitFor();
            if (containerId != null) {
                System.out.println("Container ID: " + containerId);
            } else {
                System.out.println(String.format("No container found with image name  arosenfeld/immunedb"));
                containerId="";
            }
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
        return containerId;
    }

    public boolean metadata2(String dirNAme)
    {
        boolean flag=true;
        try {
            String DockerExec="docker exec -i ";

            // Create a new shell script file
            File scriptFile = new File("script.sh");
            scriptFile.createNewFile();
            //String command=" sh -c \"cd /share/input && immunedb_metadata --use-filenames\"";
            String command = " sh -c \"cd /share/" + dirNAme + " && immunedb_metadata --use-filenames\"";


            // Write the command to the file
            BufferedWriter bw = new BufferedWriter(new FileWriter(scriptFile));
            ExtraData extra=new ExtraData();
            bw.write(DockerExec+extra.getConID()+command);
            bw.close();

            // Make the file executable
            scriptFile.setExecutable(true);

            // Run the file
            Process p = Runtime.getRuntime().exec("./script.sh");
            p.waitFor();
            BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream()));
            BufferedReader stderr = new BufferedReader(new InputStreamReader(p.getErrorStream()));

            String line = "";
            while ((line = stderr.readLine()) != null) {
                txtAre.appendText(line);
                txtAre.appendText("\n");
                flag=false;
            }
            while ((line = reader.readLine())!= null) {
                System.out.println(line);
            }
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
        return flag;
    }

    public boolean RunDockerCommand1(String command)
    {
        boolean flag =true;
        try {
            String DockerExec="docker exec -i ";
            ExtraData extra=new ExtraData();
            contID=extra.getConID();
            DockerExec+=contID;
            DockerExec+=command;

            Process runProcess = Runtime.getRuntime().exec(DockerExec);
            BufferedReader stderr = new BufferedReader(new InputStreamReader(runProcess.getErrorStream()));
            String line;
            while ((line = stderr.readLine()) != null) {
                txtAre.appendText(line);
                txtAre.appendText("\n");
                flag=false;
            }
            int exitStatus = runProcess.waitFor();
            BufferedReader stdout = new BufferedReader(new InputStreamReader(runProcess.getInputStream()));
            while ((line = stdout.readLine()) != null) {
                txtAre.appendText(line);
                txtAre.appendText("\n");
            }
            txtAre.appendText("Exit status: " + exitStatus);
            txtAre.appendText("\n");
        } catch (IOException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        return flag;
    }

//RUn the metadat command
    public boolean RunDockerCommand(String comm)
    {
        boolean flag=true;
        try {
            String DockerExec="docker exec -i ";

            ExtraData extra=new ExtraData();
            // Create a new shell script file
            File scriptFile = new File("script.sh");
            scriptFile.createNewFile();
            //String command=" sh -c \"cd /share/input && immunedb_metadata --use-filenames\"";
            String command = " sh -c \"cd /share/" + extra.getDirName() + " && "+comm+"\"";


            // Write the command to the file
            BufferedWriter bw = new BufferedWriter(new FileWriter(scriptFile));

            bw.write(DockerExec+extra.getConID()+command);
            bw.close();

            // Make the file executable
            scriptFile.setExecutable(true);

            // Run the file
            Process p = Runtime.getRuntime().exec("./script.sh");
            p.waitFor();
            BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream()));
            BufferedReader stderr = new BufferedReader(new InputStreamReader(p.getErrorStream()));

            String line = "";
            while ((line = stderr.readLine()) != null) {
                txtAre.appendText(line);
                txtAre.appendText("\n");
                flag=false;
            }
            while ((line = reader.readLine())!= null) {
                System.out.println(line);
            }
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
        return flag;
    }

    public boolean DockerPull2()
    {
        boolean flag=true;
        //Check if the docker image has benn ppulled befor pulling
        List<String> pullCommand = new ArrayList<>();
        pullCommand.add("docker");
        pullCommand.add("pull");
        pullCommand.add("arosenfeld/immunedb");
        ProcessBuilder pullBuilder = new ProcessBuilder(pullCommand);
        Process pullProcess = null;
        try {
            pullProcess = pullBuilder.start();
            pullProcess.waitFor();
            BufferedReader reader = new BufferedReader(new InputStreamReader(pullProcess.getInputStream()));
            String line;
            while ((line = reader.readLine()) != null) {
                txtAre.appendText(line);
                txtAre.appendText("\n");
                System.out.println(line);
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
       // btn.setDisable(false);
        return flag;
    }


    //////////////////////////////////// END NEW COMMANDS///////////////////////////////////////////////////


    /////////////////////////////////// OLd commands///////////////////////////////////////////////////////
   /* public boolean RunDockerCommand(String command)
    {
        boolean flag =true;
        try {
                ExtraData extra=new ExtraData();
                contID=extra.getConID();
                DockerExec+=contID;
                DockerExec+=command;

            Process runProcess = Runtime.getRuntime().exec(DockerExec);
            BufferedReader stderr = new BufferedReader(new InputStreamReader(runProcess.getErrorStream()));
            String line;
            while ((line = stderr.readLine()) != null) {
                txtAre.appendText(line);
                txtAre.appendText("\n");
                flag=false;
            }
            int exitStatus = runProcess.waitFor();
            BufferedReader stdout = new BufferedReader(new InputStreamReader(runProcess.getInputStream()));
            while ((line = stdout.readLine()) != null) {
                txtAre.appendText(line);
                txtAre.appendText("\n");
            }
            txtAre.appendText("Exit status: " + exitStatus);
            txtAre.appendText("\n");
        } catch (IOException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        return flag;
    }*/

   //* public boolean RunDockerCommand(String command)
   //    {
   //        final boolean flag=true;
   //        final Process[] runProcess = new Process[1];
   //        String line;
   //        Service<Void> service = new Service<Void>() {
   //            @Override
   //            protected Task<Void> createTask() {
   //                return new Task<Void>() {
   //                    @Override
   //                    protected Void call() throws Exception {
   //                        //Background work
   //                        final boolean[] flag = {true};
   //                        try{
   //                            ExtraData extra=new ExtraData();
   //                            contID=extra.getConID();
   //                            DockerExec+=contID;
   //                            DockerExec+=" ";
   //                            DockerExec+=command;
   //
   //                            runProcess[0] = Runtime.getRuntime().exec(DockerExec);
   //                            int exitStatus = runProcess[0].waitFor();
   //                        } catch (IOException e) {
   //                            throw new RuntimeException(e);
   //                        } catch (InterruptedException e) {
   //                            throw new RuntimeException(e);
   //                        }
   //                        final CountDownLatch latch = new CountDownLatch(1);
   //                        Platform.runLater(new Runnable() {
   //                            @Override
   //                            public void run() {
   //                                BufferedReader stderr = new BufferedReader(new InputStreamReader(runProcess[0].getErrorStream()));
   //                                String line;
   //                                BufferedReader stdout = new BufferedReader(new InputStreamReader(runProcess[0].getInputStream()));
   //                                try{
   //                                    while ((line = stdout.readLine()) != null) {
   //                                        txtAre.appendText(line);
   //                                        txtAre.appendText("\n");
   //                                        flag[0] =false;
   //                                    }
   //                                    while ((line = stderr.readLine()) != null) {
   //                                        txtAre.appendText(line);
   //                                        txtAre.appendText("\n");
   //                                    }
   //                                    //FX Stuff done here
   //
   //                                } catch (IOException e) {
   //                                    throw new RuntimeException(e);
   //                                } finally{
   //                                    latch.countDown();
   //                                }
   //                            }
   //                        });
   //                        latch.await();
   //                        //Keep with the background work
   //                        return null;
   //                    }
   //                };
   //            }
   //        };
   //        service.start();
   //        return true;
   //    }*//
    public boolean RunDockerCommand23(String command,Button btn)
    {
        final boolean flag=true;
        final Process[] runProcess = new Process[1];
        String line;
        Service<Void> service = new Service<Void>() {
            @Override
            protected Task<Void> createTask() {
                return new Task<Void>() {
                    @Override
                    protected Void call() throws Exception {
                        //Background work
                        final boolean[] flag = {true};
                        try{
                             String DockerExec="docker exec -i ";


                            ExtraData extra=new ExtraData();
                            contID=extra.getConID();
                            DockerExec+=contID;
                            DockerExec+=" ";
                            DockerExec+=command;

                            runProcess[0] = Runtime.getRuntime().exec(DockerExec);
                            int exitStatus = runProcess[0].waitFor();
                        } catch (IOException e) {
                            throw new RuntimeException(e);
                        } catch (InterruptedException e) {
                            throw new RuntimeException(e);
                        }
                        final CountDownLatch latch = new CountDownLatch(1);
                        Platform.runLater(new Runnable() {
                            @Override
                            public void run() {
                                BufferedReader stderr = new BufferedReader(new InputStreamReader(runProcess[0].getErrorStream()));
                                String line;
                                BufferedReader stdout = new BufferedReader(new InputStreamReader(runProcess[0].getInputStream()));
                                try{
                                    while ((line = stdout.readLine()) != null) {
                                        txtAre.appendText(line);
                                        txtAre.appendText("\n");
                                        flag[0] =false;
                                    }
                                    while ((line = stderr.readLine()) != null) {
                                        txtAre.appendText(line);
                                        txtAre.appendText("\n");
                                    }
                                    //FX Stuff done here
                                    btn.setDisable(false);
                                } catch (IOException e) {
                                    throw new RuntimeException(e);
                                } finally{
                                    latch.countDown();
                                }
                            }
                        });
                        latch.await();
                        //Keep with the background work
                        return null;
                    }
                };
            }
        };
        service.start();
        return true;
    }


    public void DockerPull3(Button btn){
        final Process[] runProcess = new Process[1];
        String line;
        Service<Void> service = new Service<Void>() {
            @Override
            protected Task<Void> createTask() {
                return new Task<Void>() {
                    @Override
                    protected Void call() throws Exception {
                        //Background work
                        boolean flag =true;
                        try{
                            runProcess[0] = Runtime.getRuntime().exec("docker pull arosenfeld/immunedb");
                            int exitStatus = runProcess[0].waitFor();
                        } catch (IOException e) {
                            throw new RuntimeException(e);
                        } catch (InterruptedException e) {
                            throw new RuntimeException(e);
                        }
                        final CountDownLatch latch = new CountDownLatch(1);
                        Platform.runLater(new Runnable() {
                            @Override
                            public void run() {
                                BufferedReader stderr = new BufferedReader(new InputStreamReader(runProcess[0].getErrorStream()));
                                String line;
                                BufferedReader stdout = new BufferedReader(new InputStreamReader(runProcess[0].getInputStream()));
                                try{
                                    while ((line = stdout.readLine()) != null) {
                                        txtAre.appendText(line);
                                        txtAre.appendText("\n");
                                    }
                                    while ((line = stderr.readLine()) != null) {
                                        txtAre.appendText(line);
                                        txtAre.appendText("\n");
                                    }
                                    btn.setDisable(false);


                                } catch (IOException e) {
                                    throw new RuntimeException(e);
                                } finally{
                                    latch.countDown();
                                }
                            }
                        });
                        latch.await();
                        //Keep with the background work
                        return null;
                    }
                };
            }
        };
        service.start();
    }

    /* public void DokerRun() throws IOException {
        boolean flag=true;
        ProcessBuilder runBuilder = new ProcessBuilder("docker",
                "run",
                "--name",
                "MyImmuneDB",
                "-v",
                "C:/Users/user/immunedb_share:/share",
                "-p",
                "8080:8080",
                "-it",
                "-d",
                "arosenfeld/immunedb");
        Process runProcess = runBuilder.start();
        BufferedReader stderr = new BufferedReader(new InputStreamReader(runProcess.getErrorStream()));
        String line;
        while ((line = stderr.readLine()) != null) {
            txtAre.appendText(line);
            txtAre.appendText("\n");
            System.err.println(line);
            flag = false;
        }
        if (flag) {
            BufferedReader reader = new BufferedReader(new InputStreamReader(runProcess.getInputStream()));
            for (int i = 0; i < 5; i++) {
                line = reader.readLine();
                System.out.println(line);
                txtAre.appendText(line);
                txtAre.appendText("\n");
            }
        }
    }*/


    public boolean DokerRun3()
    {
        final Process[] runProcess = new Process[1];
        Service<Void> service = new Service<Void>() {
            @Override
            protected Task<Void> createTask() {
                return new Task<Void>() {
                    @Override
                    protected Void call() throws Exception {
                        //Background work
                        boolean flag =true;
                        String command;
                        try{
                            ExtraData extra=new ExtraData();
                            command="docker run -v ";
                            command +=extra.getFullpath();
                            command+=":/share -p 8080:8080 -it -d arosenfeld/immunedb";
                            runProcess[0] = Runtime.getRuntime().exec(command);
                            int exitStatus = runProcess[0].waitFor();
                        } catch (IOException e) {
                            throw new RuntimeException(e);
                        } catch (InterruptedException e) {
                            throw new RuntimeException(e);
                        }
                        final CountDownLatch latch = new CountDownLatch(1);
                        Platform.runLater(new Runnable() {
                            @Override
                            public void run() {
                                BufferedReader stderr = new BufferedReader(new InputStreamReader(runProcess[0].getErrorStream()));
                                String line;
                                BufferedReader stdout = new BufferedReader(new InputStreamReader(runProcess[0].getInputStream()));
                                try{

                                    while ((line = stdout.readLine()) != null) {
                                        txtAre.appendText(line);
                                        txtAre.appendText("\n");
                                    }
                                    while ((line = stderr.readLine()) != null) {
                                        txtAre.appendText(line);
                                        txtAre.appendText("\n");
                                    }

                                } catch (IOException e) {
                                    throw new RuntimeException(e);
                                } finally{
                                    latch.countDown();
                                }
                            }
                        });
                        latch.await();
                        return null;
                    }
                };
            }
        };
        service.start();
        return true;
    }


    public boolean metadata3()
    {
        final boolean[] flag = {true};
        final Process[] runProcess = new Process[1];
        String line;
        Service<Void> service = new Service<Void>() {
            @Override
            protected Task<Void> createTask() {
                return new Task<Void>() {
                    @Override
                    protected Void call() throws Exception {
                        //Background work
                        //String command = "docker exec -i a5780fe71c77 sh -c \"cd /share/input && immunedb_metadata --use-filenames\"";
                        try {
                             String DockerExec="docker exec -i ";

                            // Create a new shell script file
                            ExtraData extra = new ExtraData();
                            File scriptFile = new File("script.sh");
                            scriptFile.createNewFile();
                            DockerExec += extra.getConID();
                            DockerExec += "sh -c \"cd /share/input && immunedb_metadata --use-filenames\"";
                            // Write the command to the file
                            BufferedWriter bw = new BufferedWriter(new FileWriter(scriptFile));
                            bw.write(DockerExec);
                            bw.close();
                            // Make the file executable
                            scriptFile.setExecutable(true);

                            // Run the file
                             runProcess[0]= Runtime.getRuntime().exec("./script.sh");
                            runProcess[0].waitFor();
                        } catch (IOException e) {
                            throw new RuntimeException(e);
                        } catch (InterruptedException e) {
                            throw new RuntimeException(e);
                        }
                        final CountDownLatch latch = new CountDownLatch(1);
                        Platform.runLater(new Runnable() {
                            @Override
                            public void run() {
                                BufferedReader stderr = new BufferedReader(new InputStreamReader(runProcess[0].getErrorStream()));
                                String line;
                                BufferedReader stdout = new BufferedReader(new InputStreamReader(runProcess[0].getInputStream()));
                                try{
                                    while ((line = stdout.readLine()) != null) {

                                        txtAre.appendText(line);
                                        txtAre.appendText("\n");
                                        flag[0] =false;
                                    }
                                    while ((line = stderr.readLine()) != null) {
                                        txtAre.appendText(line);
                                        txtAre.appendText("\n");
                                    }
                                    //FX Stuff done here

                                } catch (IOException e) {
                                    throw new RuntimeException(e);
                                } finally{
                                    latch.countDown();
                                }
                            }
                        });
                        latch.await();
                        //Keep with the background work
                        return null;
                    }
                };
            }
        };
        service.start();
        return flag[0];
    }

    //////////////////////////////////////////////////////////////////////////////////////////////////////////

}
