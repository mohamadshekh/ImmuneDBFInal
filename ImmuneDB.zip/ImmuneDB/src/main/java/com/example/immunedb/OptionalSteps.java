package com.example.immunedb;

import javafx.collections.FXCollections;
import javafx.concurrent.Task;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Button;
import javafx.scene.control.SplitPane;
import javafx.scene.control.TextArea;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import javax.swing.*;
import java.io.IOException;

public class OptionalSteps {

    @FXML
    private static SplitPane split;
    public Button RunClone;
    public Button Selection;
    private AnchorPane lowerAnchorPane;
    private static TextArea txtAre;
    private RunDockerCommandController runCommand;


    public void settxt(TextArea txt)
    {
        txtAre=txt;
    }
    public void setSplit(SplitPane ss)
    {
        split=ss;
    }
    @FXML
    public void initialize() {


    runCommand=new RunDockerCommandController();

    }
    public void start() throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("OptionalSteps.fxml"));
        lowerAnchorPane = loader.load();
        split.getItems().set(0, lowerAnchorPane);
    }

    public void SelectionPRRun(ActionEvent actionEvent) {
        int result = JOptionPane.showConfirmDialog(null, "Please consider that Selection pressure calculations are time-consuming, so you can skip this step if time is limited", "Confirm", JOptionPane.YES_NO_OPTION);
        if (result == JOptionPane.YES_OPTION) {
            // user pressed the "Yes" button
            //run selection pressure command  immunedb_clone_pressure /share/configs/example_db.json /apps/baseline/Baseline_Main.r
            RunClone.setDisable(true);
            ExtraData etra =new ExtraData();
            etra.setSelection(true);
            String command =" immunedb_clone_pressure /share/configs/";
            command+=etra.getDBname();
            command+=".json /apps/baseline/Baseline_Main.r";
            txtAre.appendText("\n optional  "+command);

           // /RunDockerCommandController run=new RunDockerCommandController();
            //run.RunDockerCommand2(command,RunClone);
            runCommand2(command,Selection);
        } else if (result == JOptionPane.NO_OPTION) {
            // user pressed the "No" button

        }
    }

    private void runCommand2(String command,Button btn)
    {
        LoadingDialog dialog = new LoadingDialog();
        Task<Void> task = new Task<Void>() {
            @Override
            protected Void call() throws Exception {
                split.setDisable(true);
                btn.setDisable(true);
                runCommand.RunDockerCommand(command);
                split.setDisable(false);
                return null;
            }
        };
        Stage s=new Stage();
        try {
            dialog.start(s);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        dialog.show("Performing Step... ", task);
    }

    public void CloneTreeRun(ActionEvent actionEvent) throws IOException {
        CloneTree clon=new CloneTree();
        clon.start();
    }

    public void SkipRun(ActionEvent actionEvent) throws IOException {
        LastScreen last=new LastScreen();
        last.start();
    }
}
