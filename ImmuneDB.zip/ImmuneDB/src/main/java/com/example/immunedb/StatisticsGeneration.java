package com.example.immunedb;

import javafx.collections.FXCollections;
import javafx.concurrent.Task;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Button;
import javafx.scene.control.SplitPane;
import javafx.scene.control.TextArea;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import javax.swing.*;
import java.io.IOException;

public class StatisticsGeneration {
    public Button runbtn;
    public Button nextbtn;
    public Button sample;
    private AnchorPane lowerAnchorPane;
    private RunDockerCommandController runCommand;
    private static TextArea txtAre;
    @FXML
    private static SplitPane split;

    public void settxt(TextArea txt)
    {
        this.txtAre=txt;
    }
    public void setSplit(SplitPane ss)
    {
        split=ss;
    }
    public void initialize() {
        nextbtn.setDisable(true);
        sample.setDisable(true);
        runCommand=new RunDockerCommandController();
    }
    public void start() throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("StatisticsGeneration.fxml"));
        lowerAnchorPane = loader.load();
        split.getItems().set(0, lowerAnchorPane);
    }
    public void RunStatistics(ActionEvent actionEvent) {
       // immunedb_clone_stats /share/configs/example_db.json
       // immunedb_sample_stats /share/configs/example_db.json
        RunDockerCommandController run = new RunDockerCommandController();
        ExtraData extra=new ExtraData();
        String dataName=extra.getDBname();
        String command =" immunedb_clone_stats /share/configs/";
        command+=dataName;
        command+=".json";
        txtAre.appendText("\n statis  "+command);

        //run.RunDockerCommand2(command,sample);
        runCommand(command,sample);
    }
    public void NextPressed(ActionEvent actionEvent) throws IOException {
        int result = JOptionPane.showConfirmDialog(null, "The immuneDB pipline is finished now, there are additional optional steps, whould you like to perform them ", "Confirm", JOptionPane.YES_NO_OPTION);
        if (result == JOptionPane.YES_OPTION) {
            OptionalSteps op=new OptionalSteps();
            op.start();
        } else if (result == JOptionPane.NO_OPTION) {
            LastScreen last=new LastScreen();
            last.start();
            // user pressed the "No" button
            //last screen
        }
    }

    public void sampleStat(ActionEvent actionEvent) {
        RunDockerCommandController run = new RunDockerCommandController();
        ExtraData extra=new ExtraData();
        String dataName=extra.getDBname();
        String command=" immunedb_sample_stats /share/configs/";
        command+=dataName;
        command+=".json";
        txtAre.appendText("\n statis  "+command);
        //run.RunDockerCommand2(command,nextbtn);
        runCommand(command,nextbtn);

    }

    private void runCommand(String command,Button btn)
    {
        LoadingDialog dialog = new LoadingDialog();
        Task<Void> task = new Task<Void>() {
            @Override
            protected Void call() throws Exception {
                split.setDisable(true);
                // Perform long-running operation here
                runCommand.RunDockerCommand(command);
                split.setDisable(false);
                btn.setDisable(false);
                return null;
            }
        };

        Stage s=new Stage();
        try {
            dialog.start(s);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        dialog.show("Performing Step... ", task);

    }
}
