package com.example.immunedb;

import javafx.collections.FXCollections;
import javafx.concurrent.Task;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.*;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import javax.swing.*;
import java.io.IOException;

public class ImportingOutput {

    @FXML
    private static SplitPane split;
    public Button Next;
    public Label label;
    public Button importbtn;
    public Button Seqbtn;
    private AnchorPane lowerAnchorPane;
    private static TextArea txtAre;
    @FXML
    private ComboBox<String> importingWay;
    private String method="";

    private ExtraData extradata;
    private RunDockerCommandController runCommand;


    public void settxt(TextArea txt)
    {
        this.txtAre=txt;
    }
    public void setSplit(SplitPane ss)
    {
        split=ss;
    }
    @FXML
    public void initialize() {
        ExtraData extra=new ExtraData();
        if(!extra.gettsv())
            importingWay.setItems(FXCollections.observableArrayList("Importing from AIRR Files","Annotating FASTA/FASTQ Files via Anchoring"));
        else
            importingWay.setItems(FXCollections.observableArrayList("Annotating FASTA/FASTQ Files via Anchoring"));

        Next.setDisable(true);
        importbtn.setDisable(true);
        Seqbtn.setDisable(true);

        extradata=new ExtraData();
        runCommand=new RunDockerCommandController();
    }
    public void start() throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("ImportingOutput.fxml"));
        lowerAnchorPane = loader.load();
        split.getItems().set(0, lowerAnchorPane);
    }

    public void RunImportingMethod() throws IOException {
        String command;
        //RunDockerCommandController run=new RunDockerCommandController();

        if(importingWay.getValue().equals("Importing from AIRR Files"))
            {
                if(!extradata.getIgblast())
                {
                    int result = JOptionPane.showConfirmDialog(null, "To use this method IgBLAST is required,\n if you do want to run IgBLAST press yes else no to run via the other method", "Confirm", JOptionPane.YES_NO_OPTION);
                    if (result == JOptionPane.YES_OPTION) {
                        // user pressed the "Yes" button
                        IGblastController ig=new IGblastController();
                        ig.setFlag(true);
                        ig.start();
                        command =" immunedb_import /share/configs/";
                        command+=extradata.getDBname();
                        command+=".json airr /root/germlines/igblast/human/IGHV.gapped.fasta /root/germlines/igblast/human/IGHJ.gapped.fasta /share/airr";
                        txtAre.appendText("\n importing  "+command);
                        //run.RunDockerCommand2(command,Seqbtn);
                    }
                   else {
                        command =" immunedb_identify /share/configs/";
                        command+=extradata.getDBname();
                        //command+=".json /root/germlines/anchor/human/IGHV.gapped.fasta /root/germlines/anchor/human/IGHJ.gapped.fasta /share/input";
                        command+=".json /root/germlines/anchor/human/IGHV.gapped.fasta /root/germlines/anchor/human/IGHJ.gapped.fasta /share/"+extradata.getDirName();
                        txtAre.appendText("\n importing  "+command);
                        //run.RunDockerCommand2(command,Seqbtn);
                    }
                }
                else
                {

                    command =" immunedb_import /share/configs/";
                    command+=extradata.getDBname();
                    command+=".json airr /root/germlines/igblast/human/IGHV.gapped.fasta /root/germlines/igblast/human/IGHJ.gapped.fasta /share/airr";
                    txtAre.appendText("\n importing from airr "+command);
                    //run.RunDockerCommand2(command,Seqbtn);
                }
            }
        else {
            command =" immunedb_identify /share/configs/";
            command+=extradata.getDBname();
            //command+=".json /root/germlines/anchor/human/IGHV.gapped.fasta /root/germlines/anchor/human/IGHJ.gapped.fasta /share/input";
            command+=".json /root/germlines/anchor/human/IGHV.gapped.fasta /root/germlines/anchor/human/IGHJ.gapped.fasta /share/"+extradata.getDirName();

            txtAre.appendText("\n importing  "+command);
            //run.RunDockerCommand2(command,Seqbtn);
        }
        runCommand(command,Seqbtn);

    }

    private void runCommand(String command,Button btn)
    {
        LoadingDialog dialog = new LoadingDialog();
        Task<Void> task = new Task<Void>() {
            @Override
            protected Void call() throws Exception {
                split.setDisable(true);
                // Perform long-running operation here
                runCommand.RunDockerCommand(command);
                split.setDisable(false);
                btn.setDisable(false);
                return null;
            }
        };

        Stage s=new Stage();
        try {
            dialog.start(s);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        dialog.show("Performing Step... ", task);

    }

    public void nextStep(ActionEvent actionEvent) throws IOException {
        ClonalAssignment clone=new ClonalAssignment();
        clone.start();
    }

    public void ImportMethodChoose(ActionEvent actionEvent) {
        if(importingWay.getValue().equals("Importing from AIRR Files")) {
            method="AIRR";
        }
        else{
            method="Annotating";
        }
        importbtn.setDisable(false);
    }

    public void runSequeneceCollapsing(ActionEvent actionEvent) {

        String command=" immunedb_collapse /share/configs/";
        command+=extradata.getDBname();
        command+=".json";
        txtAre.appendText("\n importing  "+command);
        runCommand(command,Next);
        //run.RunDockerCommand2(command,Next);
    }
}
