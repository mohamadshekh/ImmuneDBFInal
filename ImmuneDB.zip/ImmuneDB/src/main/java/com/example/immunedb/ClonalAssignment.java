package com.example.immunedb;

import javafx.beans.value.ChangeListener;
import javafx.collections.FXCollections;
import javafx.concurrent.Task;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.*;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import javax.swing.*;
import java.io.IOException;

public class ClonalAssignment {
    @FXML
    private static SplitPane split;

    public Button Next;
    public ComboBox type;
    public TextField subjectText;
    public ComboBox method;
    public Button Runbtn;
    public CheckBox checkBox;
    public TextField similText;
    public CheckBox checkboxSimilarity;

    private AnchorPane lowerAnchorPane;
    private static TextArea txtAre;
    private String Subject="";
    private String sim="";
    private String datasetType="";
    private String methodtype="";
    private ExtraData extradata;
    private RunDockerCommandController runCommand;

    private String message = "";
    private String title = "Error";
    public void settxt(TextArea txt)
    {
        this.txtAre=txt;
    }
    public void setSplit(SplitPane ss)
    {
        split=ss;
    }
    private String AddCommandSimilarity="";
    private String AddCommandSubject="";


    @FXML
    public void initialize() {
        type.setItems(FXCollections.observableArrayList("B-cells","T-cells","mixed"));
        method.setItems(FXCollections.observableArrayList("similarity","cluster","Run Recommended"));
        Next.setDisable(true);
        Runbtn.setDisable(true);
        type.setDisable(true);
        checkboxSimilarity.setDisable(true);
         extradata=new ExtraData();
        runCommand=new RunDockerCommandController();
        subjectText.textProperty().addListener(textListener);
        similText.textProperty().addListener(textListener);

    }
    public void start() throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("ClonalAssignment.fxml"));
        lowerAnchorPane = loader.load();
        split.getItems().set(0, lowerAnchorPane);
    }
    public void showAlert(String msg) {
        JOptionPane.showMessageDialog(null, msg, "Error", JOptionPane.INFORMATION_MESSAGE);
    }
    public void onChooseType(ActionEvent actionEvent) {
       this.datasetType= (String) type.getValue();
        Runbtn.setDisable(false);
    }
    public void getSubjectNumber( ) {
        try {
            int input = Integer.parseInt(subjectText.getText());
            if(checkBox.isSelected()) {
                AddCommandSubject = " --min-copy ";
                AddCommandSubject += subjectText.getText();
            }
            // Input is a valid integer, do something with it
        } catch (NumberFormatException e) {
            AddCommandSubject="";
            subjectText.setText("");
           showAlert("Please enter a valid subject-level copy number (integer)");
        }
    }
    public void GetSimilarity( ) {
        try {
           float input = Float.parseFloat(similText.getText());
           if(input<0||input>1)
               showAlert("Please enter a valid similarty between 0 and 1");
           else {
               if(checkBox.isSelected()) {
                   AddCommandSimilarity = " --min-similarity ";
                   AddCommandSimilarity += similText.getText();
               }
               }

        } catch (NumberFormatException e) {
            AddCommandSimilarity="";
            subjectText.setText("");
            showAlert("Please enter a valid similarty between 0 and 1");
        }
    }
    public void onMethodget(ActionEvent actionEvent) {
        this.methodtype = (String) method.getValue();
        if (methodtype.equals("Run Recommended")) {
            type.setDisable(false);
            Runbtn.setDisable(true);
            checkBox.setDisable(true);
        }
        else if(this.methodtype.equals(""))
        {
            message="You must choose the method you want to use";
            JOptionPane.showMessageDialog(null, message, title, JOptionPane.ERROR_MESSAGE);
        }else
        {
            Runbtn.setDisable(false);
            type.setDisable(true);
            checkBox.setDisable(false);
        }
    }

    public void RunClonalAssignment(ActionEvent actionEvent) {

        String command="";
        String dataName=extradata.getDBname();
         if(this.methodtype.equals("Run Recommended"))
        {
            switch (this.datasetType)
            {
                case "B-cells":
                    //immunedb_clones /share/configs/my_db.json cluster
                    command=" immunedb_clones /share/configs/";
                    command+=dataName;
                    command+=".json cluster";
                    //run.RunDockerCommand2(command,Next);
                    txtAre.appendText("\n clonal assignment "+command);

                case "T-cells":
                    //immunedb_clones /share/configs/my_db.json cluster --min-similarity 1
                    command=" immunedb_clones /share/configs/";
                    command+=dataName;
                    command+=".json cluster --min-similarity 1";
                    //run.RunDockerCommand2(command,Next);
                    txtAre.appendText("\n clonal assignment "+command);

                case "mixed":
                    //immunedb_clones /share/configs/my_db.json cluster --gene IGHV
                    command=" immunedb_clones /share/configs/";
                    command+=dataName;
                    command+=".json cluster --gene IGHV";
                   // run.RunDockerCommand2(command,Next);
                    txtAre.appendText("\n clonal assignment "+command);
                    runCommand(command,Next);
                    Next.setDisable(true);

                    //immunedb_clones /share/configs/my_db.json cluster --gene TCRB --min-similarity 1
                    command=" immunedb_clones /share/configs/";
                    command+=dataName;
                    command+=".json cluster --gene TCRB --min-similarity 1";
                    //run.RunDockerCommand2(command,Next);
                    txtAre.appendText("\n clonal assignment "+command);
                    runCommand(command,Next);
            }
        }
        else {
             checkboxSimilarity.setDisable(false);
            //immunedb_clones /share/configs/my_db.json my_db
             command=" immunedb_clones /share/configs/";
             command+=dataName;
             command+=".json ";
             command+=methodtype;
             if(checkBox.isSelected())
             {
                 if(!subjectText.getText().equals(""))
                     command+=AddCommandSubject;
                 if(!similText.getText().equals(""))
                     command+=AddCommandSimilarity;
             }
             if(checkboxSimilarity.isSelected())
                    command+=" --level nt";
             //run.RunDockerCommand2(command,Next);
             txtAre.appendText("\n clonal assignment "+command);
             runCommand(command,Next);

         }

    }


    ChangeListener<String> textListener = (observable, oldValue, newValue) -> {
        try {
            if(observable.getValue().equals(subjectText)) {
                getSubjectNumber();
            }
            else {
                GetSimilarity();
            }
        } catch (NumberFormatException e) {
        }
    };



    private void runCommand(String command,Button btn)
    {
        LoadingDialog dialog = new LoadingDialog();
        Task<Void> task = new Task<Void>() {
            @Override
            protected Void call() throws Exception {
                split.setDisable(true);
                // Perform long-running operation here
                runCommand.RunDockerCommand(command);
                split.setDisable(false);
                btn.setDisable(false);
                return null;
            }
        };

        Stage s=new Stage();
        try {
            dialog.start(s);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        dialog.show("Performing Step... ", task);

    }
    public void NextStep(ActionEvent actionEvent) throws IOException {
     StatisticsGeneration sta = new StatisticsGeneration();
     sta.start();
    }
    public void info1(ActionEvent actionEvent) {
        message="By default, only sequences with a subject-level copy number greater than 1 are included in clones. This can be changed with this feild";
        JOptionPane.showMessageDialog(null, message, "information", JOptionPane.INFORMATION_MESSAGE);
    }
    public void info2(ActionEvent actionEvent) {
        message="any two sequences in a clone must (1) have the same CDR3 length and (2) share at least 85% amino-acid similarity in the CDR3.\n The similarity can be between 0 and 1 ";
        JOptionPane.showMessageDialog(null, message, "information", JOptionPane.INFORMATION_MESSAGE);
    }
    public void info3(ActionEvent actionEvent) {
        message="diffrenet command is run for each data type, by choosing mixed along with Run Recommended on the box above \n the recommended command will run ";
        JOptionPane.showMessageDialog(null, message, "information", JOptionPane.INFORMATION_MESSAGE);
    }
    public void info4(ActionEvent actionEvent) {
        message="By clicking on this choice box you can edit the parameters";
        JOptionPane.showMessageDialog(null, message, "information", JOptionPane.INFORMATION_MESSAGE);
    }
    public void info5(ActionEvent actionEvent) {
        message="If nucleotide similarity should be used, fill the checkBox in order to add the additional flag ";
        JOptionPane.showMessageDialog(null, message, "information", JOptionPane.INFORMATION_MESSAGE);
    }

}
