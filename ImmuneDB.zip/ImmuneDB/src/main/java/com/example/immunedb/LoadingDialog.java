package com.example.immunedb;

import javafx.concurrent.Task;
import javafx.concurrent.WorkerStateEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressIndicator;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class LoadingDialog extends Stage {
    private  Stage stage;
    private  ProgressIndicator progressIndicator;
    private  Label label;
    private Task<Void> task;

    public void start(Stage primaryStage) throws Exception {
        VBox root = new VBox();
        root.setAlignment(Pos.CENTER);
        progressIndicator = new ProgressIndicator();
        label = new Label("Loading...");
        root.getChildren().addAll(progressIndicator, label);
        Scene scene = new Scene(root, 200, 100);
        stage = new Stage();
        stage.initModality(Modality.APPLICATION_MODAL);
        stage.setScene(scene);
    }

    public void show(String message, Task<Void> task) {
        // set up the label and progress indicator here
        label.setText(message);
        progressIndicator.progressProperty().unbind();
        progressIndicator.progressProperty().bind(task.progressProperty());
        task.setOnSucceeded(new EventHandler<WorkerStateEvent>() {
            @Override
            public void handle(WorkerStateEvent event) {
                stage.hide();
            }
        });
        this.task = task;
        stage.show();
        new Thread(task).start();
    }


}
