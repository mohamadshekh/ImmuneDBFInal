package com.example.immunedb;

import javafx.concurrent.Task;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Button;
import javafx.scene.control.SplitPane;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import java.awt.*;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URI;
import java.util.Date;

public class LastScreen {
    public TextField link;
    private AnchorPane lowerAnchorPane;
    private static TextArea txtAre;
    private String linkString;
    @FXML
    private static SplitPane split;

    public void settxt(TextArea txt)
    {
        this.txtAre=txt;
    }
    public void setSplit(SplitPane ss)
    {
        split=ss;
    }
    public void initialize() {
        ExtraData extra=new ExtraData();
        linkString="http://localhost:8080/frontend/"+extra.getDBname();
        link.setText(linkString);
    }
    public void start() throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("LastScreen.fxml"));
        lowerAnchorPane = loader.load();
        split.getItems().set(0, lowerAnchorPane);
    }

    public void SaveTheLink(ActionEvent actionEvent) throws IOException {
        ExtraData extra=new ExtraData();
        String directory = extra.getFullpath();
        String fileName = "link.txt";
        File file = new File(directory, fileName);
        FileWriter fileWriter = new FileWriter(file, true);
        Date date = new Date();
        if (!file.exists())
            file.createNewFile();
        fileWriter.write(linkString+"  "+ date);
        fileWriter.write("\n");
        fileWriter.flush();
        fileWriter.close();

    }

    public void ExportBTN(ActionEvent actionEvent) throws IOException {
        ExportingData ex=new ExportingData();
        ex.start();
    }

    public void Exitbtn(ActionEvent actionEvent) {

        runCommand();
        System.exit(0);

    }
    private void runCommand()
    {
        LoadingDialog dialog = new LoadingDialog();
        Task<Void> task = new Task<Void>() {
            @Override
            protected Void call() throws Exception {
                split.setDisable(true);
                // Perform long-running operation here
                Thread.sleep(1000);
                ExtraData data=new ExtraData();
                RunDockerCommandController run=new RunDockerCommandController();
                run.DeleteExistingContainer(data.getConID());
                split.setDisable(false);
                return null;
            }
        };

        Stage s=new Stage();
        try {
            dialog.start(s);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        dialog.show("Performing Step... ", task);
    }

}
